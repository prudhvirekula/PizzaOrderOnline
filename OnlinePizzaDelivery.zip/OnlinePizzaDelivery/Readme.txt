# OnlinePizzaDelivery [Done by team 4]

👉 Extract the zip file and copy **OnlinePizzaDelivery** folder

    Paste inside root directory of xampp => xampp/htdocs 

👉 Open PHPMyAdmin (http://localhost/phpmyadmin)

    Create a database with name OPD
        
    Import opd.sql file(given inside the zip package in SQL file folder)
   
👉 Run the script 

    For User Panel: http://localhost/OnlinePizzaDelivery/
    
    For admin panel: http://localhost/OnlinePizzaDelivery/admin/
    
 ## Credential for Admin panel :

> username: admin      
> password: admin
